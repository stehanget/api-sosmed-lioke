<div class="modal fade pe-0" id="view" tabindex="-1" aria-labelledby="viewLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content animate__animated animate__fadeIn">
            <div class="modal-body">
                <div class="row">
                    <div class="col-12 col-lg-7 feed mb-4 mb-lg-0">

                        <div id="image-feed" class="carousel slide" data-bs-ride="carousel" data-bs-interval="false">
                            <div class="carousel-indicators">
                                
                            </div>
                            <div class="carousel-inner">
                                
                            </div>
                            <button class="carousel-control-prev" type="button" data-bs-target="#image-feed"
                                data-bs-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Previous</span>
                            </button>
                            <button class="carousel-control-next" type="button" data-bs-target="#image-feed"
                                data-bs-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Next</span>
                            </button>
                        </div>
                    </div>
                    <div id="content-feed" class="col-12 col-lg-5 border-md-start d-flex flex-column">
                        <div class="d-flex mb-3">
                            <a href="#" id="current-user-portofolio">
                                <span class="avatar me-2">
                                    <img class="rounded-circle" src="<?php echo e(asset('img/team/team-3.jpg')); ?>" width="24" height="24" style="object-fit: cover;" alt="">
                                </span>
                                <span class="user text-dark">user pembuat</span>
                            </a>
                        </div>
                        <div class="comment">
                            Category : <span class="category">anim</span>
                            <div class="description">
                                <p>description</p>
                            </div>
                            <div class="comment-body">
                                
                            </div>
                        </div>
                        <div class="input-comment mt-auto">
                            <div class="row mb-2">
                                <div class="col d-flex">
                                    <textarea id="input-comment" class="form-control" name="" rows="1"></textarea>
                                    <button id="btn-store-comment" class="btn btn-get-started m-0 py-2">Kirim</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Casper\Documents\GitHub\api-sosmed-lioke\resources\views/partials/modal/_view.blade.php ENDPATH**/ ?>