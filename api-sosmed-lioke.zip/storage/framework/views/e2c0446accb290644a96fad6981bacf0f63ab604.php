

<?php $__env->startSection('title', 'Home - LIOKE'); ?>

<?php $__env->startSection('content'); ?>
    <!-- ======= Hero Section ======= -->
    <section id="hero" class="d-flex align-items-center">
        <div class="container position-relative" data-aos="fade-up" data-aos-delay="100">
            <div class="row justify-content-center">
                <div class="col-xl-7 col-lg-9 text-center">
                    <h1>Lioke</h1>
                    <h2>Lioke adalah tujuan utama untuk menemukan & memamerkan karya kreatif dan rumah bagi para kreator terbaik dunia</h2>
                </div>
            </div>
            <?php if(!Auth::check()): ?>
                <div class="text-center">
                    <a href="#about" class="btn-get-started register-link" data-bs-toggle="modal"
                        data-bs-target="#auth">Sign
                        Up</a>
                </div>
            <?php endif; ?>
        </div>
    </section><!-- End Hero -->

    <main id="main">
        <!-- ======= Portfolio Section ======= -->
        <section id="portfolio" class="portfolio pt-0">
            <div class="container-fluid" data-aos="fade-up">
                <div class="row" data-aos="fade-up" data-aos-delay="150">
                    <div class="col-lg-12 d-flex justify-content-between">
                        <h2>Portfolio</h2>
                        <ul id="portfolio-flters">
                            <li data-filter="*" class="filter-portofolio filter-active">All</li>
                            <?php $__currentLoopData = \App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="filter-portofolio" data-filter="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>

                <div id="row-portofolio" class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 gap-y" data-aos="fade-up"
                    data-aos-delay="300">

                </div>
            </div>
    </main><!-- End #main -->

    <?php echo $__env->make('partials.modal._view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.modal._add-image', ['categories' => \App\Models\Category::get()], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom-js'); ?>
    <?php
    include 'js/home.html';
    include 'js/auth.html';
    include 'js/search.html';
    ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Casper\Documents\GitHub\api-sosmed-lioke\resources\views/auth/home.blade.php ENDPATH**/ ?>