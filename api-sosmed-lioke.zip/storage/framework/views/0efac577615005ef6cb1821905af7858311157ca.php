<div class="modal fade" id="profile" tabindex="-1" aria-labelledby="authLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content animate__animated animate__fadeIn">
            <div class="modal-body p-0">
                <div class="container-fluid">
                    <h2 class="text-center border-bottom py-2">Edit Profile</h2>
                    <div class="gap-2 d-flex flex-column">
                        <label for="edit-photo">Photo Profile <span class="text-danger form-label">*</span></label>
                        <input type="file" accept="image/*" id="edit-photo" class="form-control" placeholder="photo profile" required>
                        <label for="edit-name">Nama <span class="text-danger form-label">*</span></label>
                        <input type="text" id="edit-name" class="form-control" placeholder="nama" value="<?php echo e($user->name); ?>" required>
                        <label for="edit-nickname">Nickname <span class="text-danger form-label">*</span></label>
                        <input type="text" id="edit-nickname" class="form-control" placeholder="nickname" value="<?php echo e($user->nickname); ?>" required>
                        <label for="edit-email">Email <span class="text-danger">*</span></label>
                        <input type="email" id="edit-email" class="form-control" placeholder="email" value="<?php echo e($user->email); ?>" required>
                        <label for="edit-phone">Phone <span class="text-danger">*</span></label>
                        <input type="number" id="edit-phone" class="form-control" placeholder="phone" value="<?php echo e($user->phone); ?>" required>
                        <label for="edit-bio">Bio</label>
                        <input type="text" id="edit-bio" class="form-control" placeholder="bio">
                        <label for="edit-interest">interest</label>
                        <input type="text" id="edit-interest" class="form-control" placeholder="interest">
                    </div>
                    <button id="btn-update-profile" class="btn btn-get-started float-end my-3">Save</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Casper\Documents\GitHub\api-sosmed-lioke\resources\views/partials/modal/_edit-profile.blade.php ENDPATH**/ ?>